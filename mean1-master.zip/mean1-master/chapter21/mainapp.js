var app = angular.module('app', ['ngRoute', 'ngResource']);

app.config(['$routeProvider', function($routeProvider) {
  // See Listing 19-2 for complete code
}]);

app.factory('EmployeeService', ['$resource', function($resource) {
  // See Listing 19-3 for complete code
}]);
